Manufacturing information

Gerber files (RS274X format) and usage:

GRIPPERBOARD003.g0--top layer
GRIPPERBOARD003.g1--signal layer
GRIPPERBOARD003.g17--bottom silkscreen layer
GRIPPERBOARD003.g18--top solder layer
GRIPPERBOARD003.g19--bottom solder layer

Excellon files (2.4, Inch/Trailing zero suppression format)

GRIPPERBOARD003.e31--Excellon drill file
