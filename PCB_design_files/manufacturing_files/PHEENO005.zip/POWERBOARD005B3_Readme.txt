Manufacturing information

Gerber files (RS274X format) and usage:

POWERBOARD005B3.g0--top layer
POWERBOARD005B3.g1--signal layer
POWERBOARD005B3.g16--top silkscreen layer
POWERBOARD005B3.g18--top solder layer
POWERBOARD005B3.g19--bottom solder layer

Excellon files (2.4, Inch/Trailing zero suppression format)

POWERBOARD005B3.e31--Excellon drill file
